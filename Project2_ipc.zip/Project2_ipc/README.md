# Collapsed Building Rescue Simulation

## Project Overview
Genetic algorithm-based application for optimizing rescue operations in collapsed buildings using IPC techniques.

## Team Members
- Student 1: Fatima- Project Manager & Map Processing
- Student 2: Sorida - Genetic Algorithm
- Student 3: Shahed - IPC System
- Student 4: Aseel - Fitness Function & Path Finding

